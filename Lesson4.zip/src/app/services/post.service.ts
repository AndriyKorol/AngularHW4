import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PostService {
  posts;

  constructor() {
    this.posts = [
      {
        title: 'Title 1',
        text: 'Text 1'
      },
      {
        title: 'Title 2',
        text: 'Text 2'
      }
    ];
  }

  getPosts() {
    return this.posts;
  }
}
