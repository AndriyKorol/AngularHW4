import {Component, OnInit} from '@angular/core';
import {PostService} from '../../services/post.service';


@Component({
  selector: 'app-shopping-lists',
  templateUrl: './shopping-lists.component.html',
  styleUrls: ['./shopping-lists.component.css']
})

export class ShoppingListsComponent implements OnInit {
  post;

  constructor(
    public postService: PostService
  ) { }

  ngOnInit() {
    this.post = this.postService.getPosts();
    console.log(this.post);
  }
}






