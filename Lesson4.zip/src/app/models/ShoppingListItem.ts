export interface ShoppingListItem {
  id?: number;
  name: string;
  email: string;
  age?: number;
  phone?: number;
  comment: string;
}
