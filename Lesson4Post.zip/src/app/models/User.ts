export interface User {
  userId: number,
  email: string
}
